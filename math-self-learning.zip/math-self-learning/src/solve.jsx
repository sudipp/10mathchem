import { Graph, LongDivisionView, SyntheticView } from './Visuals.jsx'
import { P, analyze, evaluate, fromZeros, isZeroPoly, longDivide, polyLatex, polyMul, q, qLatex, synthetic, tenth } from './poly.js'

const R = String.raw
const factorLatex = ([a, b, m = 1], v = 'x') => {
  const base = b === 0 && a === 1 ? v : `(${polyLatex(P([a, b]), v)})`
  return m > 1 ? `${base}^{${m}}` : base
}
const zeroLatex = ([n, d = 1, m = 1]) => `${qLatex(q(n, d))}${m > 1 ? R`\text{ mult. }${m}` : ''}`
const divisorFor = k => polyLatex(P([1, -k]))
const linearK = den => den.length === 2 && den[0].n === 1 && den[0].d === 1 ? q(-den[1].n, den[1].d) : null

function longSolution(num, den, extra = []) {
  const r = longDivide(P(num), P(den))
  const steps = [
    R`**Set up.** Write the dividend in standard form${r.numer.some(c => c.n === 0) ? ' with **0 placeholders** for missing powers' : ''}, and the divisor outside.`,
    ...r.cycles.flatMap(c => c.explain),
    R`**Fraction form:** quotient + $\dfrac{\text{remainder}}{\text{divisor}}$ = $${r.answer}$.`,
    ...extra.map(f => f(r)),
  ]
  return { r, steps, visual: n => <LongDivisionView r={r} shown={Math.min(n - 1, r.cycles.length * 3)} /> }
}
function synthSolution(num, k, extra = []) {
  const r = synthetic(num, k)
  const steps = [
    R`**Set up.** The divisor is $${polyLatex(r.divisor)}$, so $k = ${qLatex(r.k)}$. Write the coefficients${num.some(c => c === 0) ? ' with **0 placeholders**' : ''}: $${r.coeffs.map(c => qLatex(c)).join(',\\ ')}$.`,
    ...r.steps,
    ...extra.map(f => f(r)),
  ]
  return { r, steps, visual: n => <SyntheticView r={r} shown={Math.min(n - 1, 2 * r.coeffs.length - 1)} /> }
}

export function solve(p) {
  const pre = p.label ? `${p.label}:\\ ` : ''
  if (p.type === 'long') {
    const s = longSolution(p.num, p.den)
    if (p.note) s.steps.unshift(p.note)
    const offset = p.note ? 1 : 0
    return { prompt: `${pre}(${polyLatex(P(p.num))}) \\div (${polyLatex(P(p.den))})`, steps: s.steps, visual: n => s.visual(n - offset), answer: s.r.answer }
  }
  if (p.type === 'synth') {
    const s = synthSolution(p.num, p.k, [r => R`**Read the answer.** The bottom row gives the quotient (one degree lower) and the remainder: $${r.answer}$.`])
    if (p.note) s.steps.unshift(p.note)
    const offset = p.note ? 1 : 0
    return { prompt: `${pre}(${polyLatex(P(p.num))}) \\div (${divisorFor(p.k)})`, steps: s.steps, visual: n => s.visual(n - offset), answer: s.r.answer }
  }
  if (p.type === 'eval') {
    const s = synthSolution(p.num, p.k, [r => R`**Remainder Theorem:** the remainder is $f(${qLatex(r.k)})$, so $f(${qLatex(r.k)}) = ${qLatex(r.remainder[0])}$. (Check by substituting: $f(${qLatex(r.k)}) = ${qLatex(evaluate(P(p.num), p.k))}$ ✓)`])
    return { prompt: `${pre}f(x) = ${polyLatex(P(p.num))},\\ k = ${p.k}`, steps: s.steps, visual: s.visual, answer: `f(${p.k}) = ${qLatex(s.r.remainder[0])}` }
  }
  if (p.type === 'factor') {
    const den = P(p.den)
    const k = p.method === 'long' ? null : linearK(den)
    const conclude = r => {
      const zero = isZeroPoly(r.remainder)
      return zero ? R`The remainder is $0$, so **yes**, $d(x) = ${polyLatex(den)}$ is a factor of $f(x)$.` : R`The remainder is $${polyLatex(r.remainder)}$, not $0$, so **no**, $d(x)$ is not a factor.`
    }
    const s = k ? synthSolution(p.num, k, [conclude]) : longSolution(p.num, p.den, [conclude])
    const why = k ? R`$d(x)$ is linear ($x - k$ with $k = ${qLatex(k)}$), so use **synthetic division**. A factor leaves remainder $0$.` : R`Divide $f(x)$ by $d(x)$${den[0].n !== 1 ? ' (the leading coefficient is not 1, so use **long division**)' : ''}. A factor leaves remainder $0$.`
    return { prompt: `${pre}f(x) = ${polyLatex(P(p.num))},\\ d(x) = ${polyLatex(den)}`, steps: [why, ...s.steps], visual: n => s.visual(n - 1), answer: isZeroPoly(s.r.remainder) ? R`\text{Yes}` : R`\text{No}` }
  }
  if (p.type === 'zeros') {
    const poly = p.factors.reduce((acc, [a, b, m = 1]) => { for (let i = 0; i < m; i++) acc = polyMul(acc, P([a, b])); return acc }, P([1]))
    const zeros = p.factors.map(([a, b, m = 1]) => { const z = q(-b, a); return [z.n, z.d, m] })
    const steps = [
      R`It is already in **factored form**. Use the **Zero Product Property**: set each factor equal to $0$.`,
      ...p.factors.map(([a, b, m = 1], i) => {
        const z = zeros[i]
        const eq = b === 0 && a === 1 ? 'x = 0' : `${polyLatex(P([a, b]))} = 0 \\Rightarrow x = ${qLatex(q(z[0], z[1]))}`
        return `$${eq}$${m > 1 ? ` — the factor is squared, so this zero has **multiplicity ${m}** (the graph touches the x-axis and bounces back).` : ''}`
      }),
      R`**Check with a graph:** the curve meets the x-axis at each zero.`,
    ]
    return { prompt: `${pre}f(x) = ${p.factors.map(f => factorLatex(f)).join('')}`, steps, visual: n => n >= steps.length ? <Graph poly={poly} show={{ zeros: true, extrema: false }} /> : null, answer: `\\left\\{${zeros.map(zeroLatex).join(',\\ ')}\\right\\}` }
  }
  if (p.type === 'fromZeros') {
    const { poly } = fromZeros(p.zeros)
    const facs = p.zeros.map(([n, d = 1, m = 1]) => { const z = q(n, d); return [z.d, -z.n, m] })
    const facLatex = facs.map(f => factorLatex(f)).join('')
    let running = P([1])
    const products = []
    facs.forEach(([a, b, m]) => { for (let i = 0; i < m; i++) { running = polyMul(running, P([a, b])); products.push(polyLatex(running)) } })
    const steps = [
      R`**Write a factor for each zero.** Zero $r$ gives $(x - r)$. A fraction zero $\tfrac{p}{q}$ gives $(qx - p)$ so the coefficients stay integers. Repeat a factor for each multiplicity.`,
      R`$f(x) = ${facLatex}$`,
      R`**Multiply** the factors one at a time: $${products.slice(1).length ? products.slice(1).join(R`\ \to\ `) : products[0]}$.`,
    ]
    return { prompt: `${pre}\\text{Zeros: } ${p.zeros.map(zeroLatex).join(',\\ ')}`, steps, answer: `f(x) = ${polyLatex(poly)}` }
  }
  if (p.type === 'graph') {
    const poly = P(p.num)
    const { zeros, extrema } = analyze(poly)
    const list = arr => arr.length ? arr.map(e => `(${tenth(e.x)},\\ ${tenth(e.y)})`).join(',\\ ') : R`\text{none}`
    const mins = extrema.filter(e => e.type === 'min'), maxs = extrema.filter(e => e.type === 'max')
    const steps = [
      ...(p.factorsNote ? [p.factorsNote] : []),
      R`**Graph it** (on your calculator: Y= then GRAPH, or use the picture here).`,
      R`**Real zeros** (where the curve meets the x-axis), to the nearest tenth: $${zeros.map(tenth).join(',\\ ')}$.`,
      R`**Relative maxima** (hilltops): $${list(maxs)}$. **Relative minima** (valleys): $${list(mins)}$. On a TI-84 use 2nd → CALC → maximum / minimum.`,
    ]
    const o = p.factorsNote ? 1 : 0
    return {
      prompt: p.title ?? `${pre}f(x) = ${polyLatex(poly)}`, steps,
      visual: n => n - o >= 1 ? <Graph poly={poly} window={p.window} show={{ zeros: n - o >= 2, extrema: n - o >= 3 }} /> : null,
      answer: R`\text{Zeros} \approx ${zeros.map(tenth).join(',\\ ')};\ \text{max } ${list(maxs)};\ \text{min } ${list(mins)}`,
    }
  }
  return { prompt: p.prompt, steps: p.steps, answer: p.answer }
}
