import { useEffect, useRef, useState } from 'react'
import { ArrowDown, ArrowRight, BookOpen, Check, ChevronLeft, ChevronRight, ExternalLink, FlaskConical, Pause, Play, RotateCcw, Sigma } from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import HomeworkPage from './Homework.jsx'
import { Rich, TeX } from './TeX.jsx'
import { FunctionMachine, Graph, LongDivisionView, MathLines, SyntheticView } from './Visuals.jsx'
import { P, longDivide, synthetic } from './poly.js'

gsap.registerPlugin(ScrollTrigger)
const R = String.raw

const LD = longDivide(P([2, 13, -7]), P([1, 6]))
const SYN = synthetic([1, -3, -7, 6], 4)

const TERMS = [{ tex: 'x^3', deg: 3 }, { tex: '+2', deg: 0 }, { tex: '-3x', deg: 1 }, { tex: '-2x^2', deg: 2 }]
const ORDER = [0, 3, 2, 1]
function StandardForm({ step }) {
  const placed = [0, 1, 2, 4, 4][step]
  return <div className="sf">
    <div className="sf-row">{TERMS.map((t, i) => <div key={t.tex} className={`sf-chip ${ORDER.slice(0, placed).includes(i) ? 'used' : ''}`}><TeX math={t.tex} /><span className="sf-deg">degree {t.deg}</span></div>)}</div>
    <div className="sf-arrow" aria-hidden="true">↓ highest degree first</div>
    <div className="sf-row sf-target">{ORDER.map((idx, slot) => <div key={slot} className={`sf-slot ${slot < placed ? 'filled' : ''}`}>{slot < placed && <TeX math={slot === 0 ? TERMS[idx].tex : TERMS[idx].tex} />}</div>)}</div>
    {step === 4 && <div className="sf-name"><TeX math={R`x^3 - 2x^2 - 3x + 2`} /> · degree 3 → <strong>cubic</strong> · 4 terms → <strong>polynomial with 4 terms</strong></div>}
  </div>
}

const LESSONS = [
  {
    title: 'Polynomial basics', short: 'Naming polynomials', tag: 'Standard form, degree, and names',
    intro: R`A polynomial is a sum of terms like $3x^2$, $-5x$, and $7$. Before doing anything else with a polynomial, write it in standard form and name it by its degree and number of terms.`,
    points: [
      ['Standard form', R`Write the terms from the **highest degree** (exponent) to the lowest. In standard form, the highest degree goes first: $x^3 + 2 - 3x - 2x^2$ becomes $x^3 - 2x^2 - 3x + 2$.`],
      ['Name by degree', R`Degree 0: constant · 1: linear · 2: quadratic · 3: cubic · 4: quartic · 5: quintic · 6 and up: “sixth degree”, “seventh degree”, and so on.`],
      ['Name by number of terms', R`1 term: monomial · 2 terms: binomial · 3 terms: trinomial · 4 or more: “polynomial with $n$ terms”. So $7r^6 - 4r$ is a **sixth degree binomial**.`],
    ],
    steps: [
      R`Here is $x^3 + 2 - 3x - 2x^2$ with its terms out of order. Under each term is its degree (its exponent).`,
      R`Find the highest degree: $x^3$ (degree 3) goes first.`,
      R`Next highest: $-2x^2$ (degree 2). Keep each term’s sign with it.`,
      R`Then $-3x$ (degree 1) and the constant $+2$ (degree 0).`,
      R`Standard form: $x^3 - 2x^2 - 3x + 2$. The degree is 3, so it is **cubic**, with 4 terms.`,
    ],
    visual: step => <StandardForm step={step} />,
    question: R`Name the polynomial $5x^2 - 3x^4 + 1$.`,
    options: ['Quadratic trinomial', 'Quartic trinomial', 'Quartic binomial'], correct: 1,
    explanation: R`In standard form it is $-3x^4 + 5x^2 + 1$: degree 4 (quartic) with 3 terms (trinomial).`,
    video: 'Vm7H0VTlIco', videoTitle: 'Polynomials intro', more: [['tZKzaF28sOk', 'Polynomial end behavior']],
    watch: 'Listen for the words term, coefficient, and degree. You will use them in every lesson after this.',
  },
  {
    title: 'Zeros and linear factors', short: 'Zeros & factors', tag: 'Where the graph meets the x-axis',
    intro: R`The **zeros** of a polynomial are the $x$-values that make it equal $0$. On a graph, they are where the curve crosses or touches the x-axis. Factored form makes them easy to read.`,
    points: [
      ['Zero = root = x-intercept', R`To find the zeros: 1) write the polynomial in **factored form** (always look for a GCF to factor out first); 2) set each factor equal to $0$ and solve.`],
      ['Multiplicity', R`A repeated zero is a **multiple zero**. Its **multiplicity** is how many times its factor appears. Odd multiplicity: the graph **crosses** the x-axis. Even multiplicity: it **touches and bounces back**.`],
      ['Working backwards', R`Given the zeros, write one factor for each: zero $2$ → $(x - 2)$; zero $-\tfrac{3}{2}$ → $(2x + 3)$, which keeps the coefficients whole numbers. Multiply the factors to get standard form.`],
    ],
    steps: [
      R`This is $f(x) = (x - 1)(x + 1)(x + 3)^2$ from your Day 3 notes.`,
      R`$x - 1 = 0 \Rightarrow x = 1$. Multiplicity 1 (odd): the graph **crosses** the x-axis.`,
      R`$x + 1 = 0 \Rightarrow x = -1$. Multiplicity 1: it **crosses** again.`,
      R`$(x + 3)^2 = 0 \Rightarrow x = -3$. Multiplicity 2 (even): the graph **touches and bounces back**.`,
      R`Zeros: $1$, $-1$, and $-3$ (mult. 2). Total degree $1 + 1 + 2 = 4$.`,
    ],
    visual: step => <Graph poly={P([1, 6, 8, -6, -9])} window={[-5, 3, -12, 12]} show={{ zeros: step === 4, extrema: false }} highlight={[[], [1], [-1], [-3], []][step]} label="Graph of f(x) = (x − 1)(x + 1)(x + 3)²" />,
    question: R`Which zero of $f(x) = x(x - 2)^2$ makes the graph bounce off the x-axis?`,
    options: [R`$x = 0$`, R`$x = 2$`, 'Both of them'], correct: 1,
    explanation: R`$(x - 2)$ is squared, so $x = 2$ has multiplicity 2 (even): the graph touches and turns around. $x = 0$ has multiplicity 1, so the graph crosses there.`,
    video: '1ke_xceCevk', videoTitle: 'Zeros of polynomials (multiplicity)', more: [['EtzwLlkoAnM', 'Zeros of polynomials introduction']],
    watch: 'Watch what the graph does at a zero with an even multiplicity compared with an odd one.',
    homework: 'hw3',
  },
  {
    title: 'Polynomial long division', short: 'Long division', tag: 'Divide, multiply, subtract, bring down',
    intro: R`Dividing polynomials works just like long division with numbers. $15 \div 2 = 7$ remainder $1$, so $\tfrac{15}{2} = 7 + \tfrac{1}{2}$. For polynomials: $\dfrac{f(x)}{d(x)} = q(x) + \dfrac{r(x)}{d(x)}$.`,
    points: [
      ['The cycle', R`Repeat four moves: **Divide** the leading terms, **Multiply** the divisor by that answer, **Subtract** (change the signs and add), **Bring down** the next term. Stop when what is left has a lower degree than the divisor.`],
      ['Use placeholders', R`If a power is missing, write it with a $0$ coefficient: $x^3 - 12x^2 - 42$ becomes $x^3 - 12x^2 + 0x - 42$. This keeps the columns lined up.`],
      ['Remainder Theorem', R`If $f(x)$ is divided by $(x - k)$, the remainder is $f(k)$. If the remainder is $0$, then $(x - k)$ is a **factor** of $f(x)$.`],
    ],
    steps: [R`**Set up** $(2x^2 + 13x - 7) \div (x + 6)$ (Day 4, Example 1): divisor outside, dividend inside.`, ...LD.cycles.flatMap(c => c.explain), R`**Fraction form:** $${LD.answer}$.`],
    visual: step => <LongDivisionView r={LD} shown={Math.min(step, LD.cycles.length * 3)} />,
    question: R`You divide $f(x)$ by $x - 3$ and the remainder is $0$. What does that tell you?`,
    options: [R`$x - 3$ is a factor of $f(x)$`, R`$f(0) = 3$`, 'The quotient is 0'], correct: 0,
    explanation: R`By the Remainder Theorem, $f(3) = 0$, which means $(x - 3)$ divides evenly: it is a factor.`,
    video: '4u8_AMacu-Y', videoTitle: 'Algebraic long division', more: [['MwG6QD352yc', 'Polynomial remainder theorem'], ['3eowXt_LNbg', 'Polynomial division introduction']],
    watch: 'Pause after each “divide” step and predict the next term of the quotient before he writes it.',
    homework: 'hw4',
  },
  {
    title: 'Synthetic division', short: 'Synthetic division', tag: 'A shortcut for dividing by x − k',
    intro: R`Synthetic division is a fast way to divide by a **linear** divisor like $x - 4$ or $x + 2$. It only works with linear divisors, and it uses just the coefficients.`,
    points: [
      ['Set up', R`For a divisor $x - k$, put $k$ in the box. For $x + 2$, $k = -2$. Write the coefficients in standard form, with $0$ for any missing power.`],
      ['Bring down, multiply, add', R`Bring down the first coefficient. Multiply it by $k$, write the product under the next coefficient, and add. Repeat to the end.`],
      ['Read the answer', R`The last number is the **remainder**. The others are the quotient’s coefficients, starting **one degree lower** than $f(x)$. The remainder is also $f(k)$, so this is a fast way to evaluate $f(k)$.`],
    ],
    steps: [R`**Set up** $(x^3 - 3x^2 - 7x + 6) \div (x - 4)$ (Day 5, Example 1): $k = 4$, coefficients $1, -3, -7, 6$.`, ...SYN.steps, R`**Read the answer:** $${SYN.answer}$.`],
    visual: step => <SyntheticView r={SYN} shown={Math.min(step, 2 * SYN.coeffs.length - 1)} />,
    question: R`To divide by $x + 5$ with synthetic division, which number goes in the box?`,
    options: ['5', '−5', '1'], correct: 1,
    explanation: R`$x + 5 = x - (-5)$, so $k = -5$.`,
    video: '1byR9UEQJN0', videoTitle: 'Synthetic division', more: [['z7JiQ5etCZs', 'Intro to polynomial synthetic division'], ['-nlMXVrgtjw', 'Why synthetic division works']],
    watch: 'Notice that he only writes the coefficients. Compare each row with the long division version.',
    homework: 'hw5',
  },
  {
    title: 'Factoring higher-degree polynomials', short: 'Factoring', tag: 'Cubes, quadratic form, and grouping',
    intro: R`To factor polynomials with degree higher than 2, **always take out the GCF first**, then look for one of three patterns.`,
    points: [
      ['Sum and difference of cubes', R`$a^3 + b^3 = (a + b)(a^2 - ab + b^2)$ and $a^3 - b^3 = (a - b)(a^2 + ab + b^2)$. Remember **SOAP** for the signs: Same, Opposite, Always Positive.`],
      ['Quadratic form', R`If the exponents are 4 and 2 (like $u^4 + 9u^2 + 14$), let $w = u^2$. Factor $w^2 + 9w + 14 = (w + 2)(w + 7)$, then put $u^2$ back: $(u^2 + 2)(u^2 + 7)$.`],
      ['Grouping', R`With four terms, group them in pairs and factor each pair: $35m^3 + 7m^2 - 20m - 4 = 7m^2(5m + 1) - 4(5m + 1) = (7m^2 - 4)(5m + 1)$.`],
    ],
    steps: [
      R`Factor $x^3 + 27$ (Day 7, Example 1A). Two terms, a plus sign, and both are perfect cubes → **sum of cubes**.`,
      R`Write each term as a cube: $x^3 = (x)^3$ and $27 = 3^3$. So $a = x$ and $b = 3$.`,
      R`Use the pattern $a^3 + b^3 = (a + b)(a^2 - ab + b^2)$.`,
      R`Substitute $a = x$ and $b = 3$.`,
      R`Simplify. The quadratic part $x^2 - 3x + 9$ does not factor any further.`,
    ],
    visual: step => <MathLines step={step} lines={[
      R`x^3 + 27`,
      R`= {\color{#CC5833}x}^3 + {\color{#3d6b50}3}^3`,
      R`= (a + b)(a^2 - ab + b^2)`,
      R`= ({\color{#CC5833}x} + {\color{#3d6b50}3})\big({\color{#CC5833}x}^2 - {\color{#CC5833}x}\cdot{\color{#3d6b50}3} + {\color{#3d6b50}3}^2\big)`,
      R`= (x + 3)(x^2 - 3x + 9)`,
    ]} />,
    question: R`Factor $x^3 - 8$.`,
    options: [R`$(x - 2)(x^2 + 2x + 4)$`, R`$(x - 2)(x^2 - 2x + 4)$`, R`$(x - 2)^3$`], correct: 0,
    explanation: R`Difference of cubes with $a = x$, $b = 2$: $(a - b)(a^2 + ab + b^2)$. SOAP: Same sign, Opposite sign, Always Positive.`,
    video: 'Touv2APcBRw', videoTitle: 'Factoring sum of cubes', more: [['CxcP4ylUP5w', 'Difference of cubes factoring'], ['AUBX_aHStQY', 'Factoring higher degree polynomials'], ['rR4FfB-FZJw', 'Factor expressions by grouping']],
    watch: 'Find the a and b first, then plug them into the pattern. That is the whole trick.',
    homework: 'hw7',
  },
  {
    title: 'Solving polynomial equations', short: 'Solving equations', tag: 'Factor, then use zero products',
    intro: R`To solve a polynomial equation, get $0$ on one side, **factor completely**, and set each factor equal to $0$. A polynomial of degree $n$ has $n$ roots in total, counting complex roots and multiplicity.`,
    points: [
      ['Zero Product Property', R`If $AB = 0$, then $A = 0$ or $B = 0$. It works for any number of factors: if $ABCD = 0$, at least one of them is $0$.`],
      ['Complex roots', R`Sometimes a factor like $y^2 + 3 = 0$ has no real solution. Then $y^2 = -3$, so $y = \pm\sqrt{-3} = \pm i\sqrt3$. Write complex answers in $a + bi$ form.`],
      ['Quadratic formula when stuck', R`If a quadratic factor will not factor, use $x = \dfrac{-b \pm \sqrt{b^2 - 4ac}}{2a}$. For $x^2 - 4x + 16 = 0$ you get $x = 2 \pm 2i\sqrt3$.`],
    ],
    steps: [
      R`Solve $2y^5 - 18y = 0$ (Day 7, Example 5A). It already has $0$ on one side.`,
      R`**GCF:** both terms share $2y$.`,
      R`$y^4 - 9$ is a **difference of squares**: $(y^2)^2 - 3^2$.`,
      R`**Zero Product Property:** set each factor equal to $0$.`,
      R`Solve each one. $y^2 = -3$ gives the complex roots $\pm i\sqrt3$. Degree 5 → 5 roots in total.`,
    ],
    visual: step => <MathLines step={step} lines={[R`2y^5 - 18y = 0`, R`2y(y^4 - 9) = 0`, R`2y(y^2 - 3)(y^2 + 3) = 0`, R`2y = 0 \qquad y^2 - 3 = 0 \qquad y^2 + 3 = 0`, R`y = 0,\ \pm\sqrt3,\ \pm i\sqrt3`]} />,
    question: R`How many roots (real and complex together) does $x^4 + 64x = 0$ have?`,
    options: ['2', '3', '4'], correct: 2,
    explanation: R`It has degree 4, so 4 roots: $0$, $-4$, and $2 \pm 2i\sqrt3$.`,
    video: '7y_2jQlnKag', videoTitle: 'Introduction to factoring higher degree polynomials', more: [['8TPofjGXDR4', 'Factoring sum of squares (complex numbers)']],
    watch: 'Each time a factor is found, ask: what value of x makes this factor zero?',
    homework: 'hw7',
  },
  {
    title: 'Function operations and composition', short: 'Function operations', tag: 'Add, multiply, and plug in',
    intro: R`You can add, subtract, multiply, and divide functions, and you can put one function inside another. These skills appear all through the HW #6 review.`,
    points: [
      ['Operations', R`$(f + g)(x) = f(x) + g(x)$ and $(f \cdot g)(x) = f(x) \cdot g(x)$. When subtracting, put the **whole** second function in parentheses: $h(n) - g(n) = (-2n + 2) - (n^2 + 1)$.`],
      ['Plugging in expressions', R`To find $g(-4t)$, replace every $a$ in $g(a)$ with $(-4t)$, **in parentheses**: $(-4t)^3 = -64t^3$, not $-4t^3$.`],
      ['Composition', R`$g(h(x))$, also written $(g \circ h)(x)$, means work **inside out**: find $h(x)$ first, then put that whole answer into $g$.`],
    ],
    steps: [
      R`$g(x) = 3x - 3$ and $h(x) = x^3 - 2$. To find $g(h(x))$, start with the input $x$.`,
      R`The **inside** function goes first: $h$ turns $x$ into $x^3 - 2$.`,
      R`Now $g$ takes that whole expression as its input: replace $x$ in $3x - 3$ with $(x^3 - 2)$.`,
      R`Simplify: $3x^3 - 6 - 3 = 3x^3 - 9$. (This is HW #6, problem 11.)`,
      R`Check with a number: $h(2) = 6$, then $g(6) = 15$. And $3(2)^3 - 9 = 15$ ✓.`,
    ],
    visual: step => <FunctionMachine step={step} />,
    question: R`If $f(x) = x - 1$, what is $f(f(1))$?`,
    options: ['0', '−1', '1'], correct: 1,
    explanation: R`Inside first: $f(1) = 0$. Then $f(0) = -1$.`,
    video: 'wUNWjd4bMmw', videoTitle: 'Introduction to function composition', more: [['lxtlwnCV-HM', 'Evaluating composite functions']],
    watch: 'Watch the order: the function written on the inside is always used first.',
    homework: 'hw6',
  },
]
const HW_FOR = { 0: 'hw6', 1: 'hw3', 2: 'hw4', 3: 'hw5', 4: 'hw7', 5: 'hw7', 6: 'hw6' }

// Bookshelf in learning order: lessons in class order, and within each
// lesson the introduction first, then the main skill, then extensions.
const SHELF = [
  [['Vm7H0VTlIco', 'Polynomials intro'], ['tZKzaF28sOk', 'Polynomial end behavior']],
  [['EtzwLlkoAnM', 'Zeros of polynomials introduction'], ['1ke_xceCevk', 'Zeros of polynomials (multiplicity)']],
  [['3eowXt_LNbg', 'Polynomial division introduction'], ['4u8_AMacu-Y', 'Algebraic long division'], ['MwG6QD352yc', 'Polynomial remainder theorem']],
  [['z7JiQ5etCZs', 'Intro to polynomial synthetic division'], ['1byR9UEQJN0', 'Synthetic division'], ['-nlMXVrgtjw', 'Why synthetic division works']],
  [['7y_2jQlnKag', 'Introduction to factoring higher degree polynomials'], ['Touv2APcBRw', 'Factoring sum of cubes'], ['CxcP4ylUP5w', 'Difference of cubes factoring'], ['AUBX_aHStQY', 'Factoring higher degree polynomials (quadratic form)'], ['rR4FfB-FZJw', 'Factor expressions by grouping']],
  [['8TPofjGXDR4', 'Factoring sum of squares (complex roots)']],
  [['wUNWjd4bMmw', 'Introduction to function composition'], ['lxtlwnCV-HM', 'Evaluating composite functions']],
]

function Button({ children, className = '', ...props }) {
  return <button className={`button ${className}`} {...props}><span className="button-wash" aria-hidden="true" /><span className="button-label">{children}</span></button>
}

function AnimationPlayer({ lesson }) {
  const [step, setStep] = useState(0)
  const [playing, setPlaying] = useState(false)
  const ref = useRef(null)
  const steps = lesson.steps
  useEffect(() => {
    if (!playing) return
    const timer = setInterval(() => setStep(s => { if (s >= steps.length - 1) { setPlaying(false); return s } return s + 1 }), 4500)
    return () => clearInterval(timer)
  }, [playing, steps.length])
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const targets = ref.current?.querySelectorAll('.new, .math-line.current, .sf-slot.filled')
    if (!targets?.length) return
    const tween = gsap.from(targets, { opacity: 0, y: 6, duration: 0.45, ease: 'power2.out' })
    return () => tween.revert()
  }, [step])
  const move = next => { setPlaying(false); setStep(next) }
  return <div className="animation-player" ref={ref}>
    <div className="player-top"><span className="eyebrow">STEP-BY-STEP ANIMATION</span><span className="mono">STEP {step + 1} / {steps.length}</span></div>
    <div className="drawing">{lesson.visual(step)}</div>
    <div className="step-caption" aria-live="polite"><Rich text={steps[step]} /></div>
    <div className="player-controls">
      <Button className="icon-button" aria-label="Restart animation" onClick={() => move(0)}><RotateCcw size={17} /></Button>
      <Button className="icon-button" aria-label="Previous step" disabled={step === 0} onClick={() => move(step - 1)}><ChevronLeft size={20} /></Button>
      <Button className="accent" onClick={() => { if (step === steps.length - 1) setStep(0); setPlaying(!playing) }}>{playing ? <Pause size={16} /> : <Play size={16} />}{playing ? 'Pause' : 'Play steps'}</Button>
      <Button className="icon-button" aria-label="Next step" disabled={step === steps.length - 1} onClick={() => move(step + 1)}><ChevronRight size={20} /></Button>
    </div>
  </div>
}

function Video({ lesson }) {
  const [loaded, setLoaded] = useState(false)
  return <section className="video-card">
    <div className="section-label"><Play size={16} /><span className="eyebrow">WATCH WITH A TEACHER</span></div>
    <h3>{lesson.videoTitle}</h3>
    <p className="muted">Khan Academy · YouTube</p>
    <div className="video-frame">
      {loaded ? <iframe title={lesson.videoTitle} src={`https://www.youtube-nocookie.com/embed/${lesson.video}?rel=0`} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /> :
        <Button className="accent" onClick={() => setLoaded(true)}><Play size={18} /> Load video</Button>}
    </div>
    <p><strong>While watching:</strong> {lesson.watch}</p>
    <a className="text-link" href={`https://www.youtube.com/watch?v=${lesson.video}`} target="_blank" rel="noreferrer">Watch on YouTube <ExternalLink size={14} /></a>
    {lesson.more?.length > 0 && <div className="more-videos"><span className="eyebrow">MORE FROM KHAN ACADEMY</span>{lesson.more.map(([id, title]) => <a key={id} href={`https://www.youtube.com/watch?v=${id}`} target="_blank" rel="noreferrer">{title} <ExternalLink size={13} /></a>)}</div>}
    <small>Videos need an internet connection and may be restricted on some networks. If the player does not load, use the direct link.</small>
  </section>
}

function Quiz({ lesson, onComplete, completed }) {
  const [answer, setAnswer] = useState(null)
  const [checked, setChecked] = useState(false)
  const correct = answer === lesson.correct
  return <section className="quiz">
    <span className="eyebrow">CHECK YOUR UNDERSTANDING</span>
    <h3><Rich text={lesson.question} /></h3>
    <div className="answers" role="group" aria-label="Answer choices">{lesson.options.map((option, i) =>
      <button key={option} className={`answer ${answer === i ? 'chosen' : ''}`} aria-pressed={answer === i} onClick={() => { setAnswer(i); setChecked(false) }}><span>{String.fromCharCode(65 + i)}</span><Rich text={option} /></button>)}</div>
    <Button className="primary" disabled={answer === null} onClick={() => { setChecked(true); if (correct) onComplete() }}>Check answer <ArrowRight size={16} /></Button>
    {checked && <p className={`feedback ${correct ? 'correct' : ''}`} role="status"><strong>{correct ? 'Exactly right. ' : 'Not quite — try again. '}</strong><Rich text={lesson.explanation} /></p>}
    {completed && <p className="completed"><Check size={16} /> Lesson check passed</p>}
  </section>
}

const routeFromHash = () => {
  const hash = window.location.hash
  if (hash.startsWith('#/homework')) return { page: 'homework', tab: hash.split('/')[2] ?? 'hw3' }
  return { page: 'home' }
}

export default function App() {
  const [active, setActive] = useState(0)
  const [completed, setCompleted] = useState([])
  const [scrolled, setScrolled] = useState(false)
  const [route, setRoute] = useState(routeFromHash)
  const root = useRef(null)
  const lesson = LESSONS[active]
  const count = LESSONS.length
  useEffect(() => {
    const onHashChange = () => {
      const next = routeFromHash()
      setRoute(next)
      if (next.page !== 'home') window.scrollTo({ top: 0, behavior: 'instant' })
    }
    window.addEventListener('hashchange', onHashChange)
    return () => window.removeEventListener('hashchange', onHashChange)
  }, [])
  useEffect(() => {
    if (route.page !== 'home') return
    const target = window.location.hash.slice(1)
    if (target && target !== 'home') document.getElementById(target)?.scrollIntoView({ behavior: 'instant' })
    const observer = new IntersectionObserver(([entry]) => setScrolled(!entry.isIntersecting), { threshold: 0.2 })
    observer.observe(document.getElementById('home'))
    const ctx = gsap.context(() => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
      gsap.from('.hero-reveal', { y: 40, opacity: 0, stagger: 0.08, duration: 1.1, ease: 'power3.out' })
      gsap.utils.toArray('.reveal').forEach(el => gsap.from(el, { y: 25, opacity: 0, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 94%', once: true }, clearProps: 'all' }))
    }, root)
    return () => { observer.disconnect(); ctx.revert() }
  }, [route.page])
  const openLesson = i => { setActive(i); window.location.hash = 'lessons' }

  return <div ref={root}>
    <a className="skip-link" href="#lessons">Skip to lessons</a>
    <header className={`navbar ${scrolled || route.page !== 'home' ? 'scrolled' : ''}`}>
      <a href="#home" className="brand"><Sigma size={25} />Self Learning<span className="brand-dot">.</span></a>
      <nav aria-label="Main navigation"><a href="#lessons">Lessons</a><a href="#/homework/hw3" aria-current={route.page === 'homework' ? 'page' : undefined}><span className="nav-long">Homework help</span><span className="nav-short">Homework</span></a><a href="#resources">Videos</a><a href="/chemistry/#lessons" className="nav-switch"><FlaskConical size={15} /> Chemistry</a></nav>
      <a className="nav-cta" href="#lessons">Start learning <ArrowRight size={15} /></a>
    </header>

    {route.page === 'homework' ? <HomeworkPage key={route.tab} tab={route.tab} openLesson={openLesson} lessonNames={LESSONS.map(l => l.title)} /> : <main>
      <section id="home" className="hero math-hero">
        <div className="hero-content">
          <div className="eyebrow hero-reveal"><span className="status-dot" /> UNIT 5 · POLYNOMIAL FUNCTIONS</div>
          <h1 className="hero-reveal">Big equations.<br /><em>Small steps.</em></h1>
          <p className="hero-reveal">Factor it, divide it, solve it.<br />Every polynomial is just a few simple moves, one after another.</p>
          <a className="hero-link hero-reveal" href="#lessons">Start your first lesson <ArrowDown size={18} /></a>
          <div className="hero-meta hero-reveal">07 SHORT LESSONS <span> / </span> KHAN ACADEMY VIDEOS <span> / </span> HOMEWORK HELP</div>
        </div>
        <span className="hero-side">EVERY BIG PROBLEM IS A FEW SMALL STEPS.</span>
      </section>

      <section className="intro-section reveal">
        <div><span className="eyebrow">ACCELERATED MATH II/III</span><h2>See it. Try it.<br /><em>Check it.</em></h2></div>
        <div className="intro-copy"><p>Each lesson follows your class notes, step by step. Watch the animation, read the short explanation, try a quick question, then use homework help to check your work.</p><div className="learning-path"><span>01 Watch the steps</span><ArrowRight size={14} /><span>02 Try one yourself</span><ArrowRight size={14} /><span>03 Check your homework</span></div></div>
      </section>

      <section id="lessons" className="lesson-section">
        <div className="lesson-header"><div><span className="eyebrow">YOUR LEARNING PATH</span><h2>From terms to <em>roots.</em></h2></div><div className="progress-summary"><span>{completed.length} / {count} checks passed</span><progress max={count} value={completed.length} aria-label="Lesson checks passed" /><small>Progress lasts for this visit.</small></div></div>
        <div className="lesson-layout">
          <aside className="lesson-nav"><span className="eyebrow">SEVEN STEPS</span>
            <div role="tablist" aria-label="Math lessons" aria-orientation="vertical">{LESSONS.map((item, i) => <button key={item.short} role="tab" id={`tab-${i}`} aria-controls="lesson-panel" aria-selected={active === i} tabIndex={active === i ? 0 : -1} className={`lesson-tab ${active === i ? 'active' : ''}`} onClick={() => setActive(i)} onKeyDown={e => {
              const keys = { ArrowDown: (i + 1) % count, ArrowUp: (i + count - 1) % count, Home: 0, End: count - 1 }
              if (Object.hasOwn(keys, e.key)) { e.preventDefault(); setActive(keys[e.key]); document.getElementById(`tab-${keys[e.key]}`).focus() }
            }}><span className="lesson-number">{completed.includes(i) ? <Check size={16} /> : `0${i + 1}`}</span><span>{item.short}</span><ChevronRight size={15} /></button>)}</div>
            <div className="sidebar-note"><BookOpen size={22} /><p>Stuck on a step?<br />Go back one and replay it.<br /><strong>Slow is smooth. Smooth is fast.</strong></p></div>
          </aside>
          <article id="lesson-panel" role="tabpanel" aria-labelledby={`tab-${active}`} tabIndex={0}>
            <div className="lesson-title"><span className="eyebrow">LESSON 0{active + 1} <span className="separator">/</span> {lesson.tag}</span><h2>{lesson.title}</h2><p className="lesson-intro"><Rich text={lesson.intro} /></p></div>
            <AnimationPlayer key={`animation-${active}`} lesson={lesson} />
            <div className="reading">{lesson.points.map(([title, text], i) => <section key={title}><span className="reading-number">0{i + 1}</span><div><h3>{title}</h3><p><Rich text={text} /></p></div></section>)}</div>
            <a className="table-callout" href={`#/homework/${HW_FOR[active]}`}><div><span className="eyebrow">PRACTICE</span><h3>{HW_FOR[active].replace('hw', 'HW #')} help</h3><p>Work through the homework with step-by-step solutions you reveal when you are ready.</p></div><ArrowRight size={22} /></a>
            <Video key={`video-${active}`} lesson={lesson} />
            <Quiz key={`quiz-${active}`} lesson={lesson} completed={completed.includes(active)} onComplete={() => setCompleted(prev => prev.includes(active) ? prev : [...prev, active])} />
            <div className="lesson-bottom"><Button disabled={active === 0} onClick={() => setActive(active - 1)}><ChevronLeft size={17} /> Previous lesson</Button><Button className="primary" disabled={active === count - 1} onClick={() => setActive(active + 1)}>Next lesson <ChevronRight size={17} /></Button></div>
          </article>
        </div>
      </section>

      <section className="manifesto reveal"><span className="eyebrow">LESS GUESSING. MORE UNDERSTANDING.</span><p>Math is not about being fast.<br />It is about knowing <em>the next step.</em></p><span>Replay an animation. Rewatch a video. Try the problem again.</span></section>
      <section id="resources" className="resources reveal">
        <div><span className="eyebrow">KEEP A TEACHER CLOSE</span><h2>Your video <em>bookshelf.</em></h2><p>Every video comes from Khan Academy and is hosted on its YouTube channel.</p></div>
        <a className="resource featured-resource" href="#/homework/hw3"><span className="eyebrow">HOMEWORK HELP</span><h3>HW #3 to HW #7, plus class notes</h3><p>Every problem, solved step by step and checked against your answer keys.</p><span className="text-link">Open homework help <ArrowRight size={16} /></span></a>
        <div className="resource-links">{(() => { let n = 0; return SHELF.map((group, i) => <div key={i} className="shelf-group">
          <span className="eyebrow shelf-lesson">LESSON 0{i + 1} · {LESSONS[i].title.toUpperCase()}</span>
          {group.map(([id, title]) => { n++; return <a key={id} href={`https://www.youtube.com/watch?v=${id}`} target="_blank" rel="noreferrer"><span className="shelf-num">{String(n).padStart(2, '0')}</span><div><strong>{title}</strong><span>Khan Academy</span></div><ExternalLink size={18} /></a> })}
        </div>) })()}</div>
      </section>
      <section className="get-started reveal"><Sigma size={36} /><h2>One step is <em>still progress.</em></h2><p>Go back to the basics whenever you need. Everything else is built on them.</p><a className="hero-link" href="#lessons" onClick={() => setActive(0)}>Back to lesson one <ArrowRight size={18} /></a></section>
    </main>}
    <footer><div><a href="#home" className="brand"><Sigma />Self Learning.</a><p>A little clearer, one step at a time.</p></div><div className="footer-links"><a href="#lessons">Read the lessons</a><a href="#/homework/hw3">Homework help</a><a href="/chemistry/#lessons">Chemistry site</a><span><span className="status-dot" /> Free to explore · No account needed</span></div><small>Independent learning resource. Not affiliated with Khan Academy; their videos remain with them. Homework problems are from your class worksheets; worked solutions are original.</small></footer>
  </div>
}
