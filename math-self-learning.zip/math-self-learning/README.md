# Self Learning: math (Unit 5 Polynomial Functions)

A React 19 learning site for Accelerated Math II/III, Unit 5, built from the
class notes (Days 3, 4, 5, 7) and HW #3 to HW #7.

## Run locally

```powershell
npm install
npm run dev -- --host 127.0.0.1
```

`npm run build` writes `dist/` (served at `/math/`), and `npm run lint` runs
static checks. To host both the chemistry and math sites on the home network,
use `..\site-host\Start Self Learning Sites.bat`.

## Lessons

1. Polynomial basics: standard form, degree, and names.
2. Zeros and linear factors: multiplicity and writing polynomials from zeros.
3. Polynomial long division and the Remainder Theorem.
4. Synthetic division and evaluating f(k).
5. Factoring: sum/difference of cubes, quadratic form, grouping.
6. Solving polynomial equations, including complex roots.
7. Function operations and composition.

Each lesson has a step-by-step animation, a short reading, a Khan Academy
video (YouTube), extra Khan Academy links, and a quick check.

## Homework help (`#/homework/<id>`)

HW #3 to HW #7 plus the class-note examples. Steps are revealed one at a time.
Division layouts, synthetic division tables, graphs (zeros, relative max/min),
and polynomials built from zeros are **computed** by `src/poly.js` with exact
fractions rather than typed by hand.

## Checking the answers

```powershell
node scripts/verify.mjs          # engine output vs. the answer keys
python scripts/verify_sympy.py   # hand-written solutions vs. sympy
```

`verify.mjs` checks every division, evaluation, factor test, zero list,
polynomial-from-zeros, and graph (zeros and extrema to the nearest tenth)
against the worksheet answer keys. It also exports the hand-written
solutions (factoring, roots, function operations) to `scripts/checks.json`,
which `verify_sympy.py` confirms with sympy (needs `pip install sympy`).
